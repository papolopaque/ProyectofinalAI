
# Se importan las librerias para el template y los renders
from django.shortcuts import render
import json


# Librerias para operaciones matemáticas
import numpy as np
# Libreria para el manejo de datos
import pandas as pd

import matplotlib.pyplot as plt
#from django_matplotlib import MatplotlibFigureField

# Libreria para cambio de datos
from sklearn.preprocessing import LabelEncoder
# Libreria para balanceo de los datos
from sklearn.utils import resample
# Libreria para separar los datos de entrenamiento y pruebas
from sklearn.model_selection import train_test_split
# Libreria para la predicción con árbol de decisión 
from sklearn.tree import DecisionTreeClassifier
# Métricas
from sklearn.metrics import confusion_matrix, classification_report, precision_score, recall_score, f1_score
# Media y la desviación estándar utilizadas en las características
from sklearn.preprocessing import StandardScaler

# Búsqueda en cuadrícula
from sklearn.model_selection import GridSearchCV

# Árbol de decisión
from sklearn.tree import DecisionTreeClassifier
# Libreria para SVM
from sklearn.svm import SVC

# Libreria para Naive Bayes
from sklearn.naive_bayes import GaussianNB

# -----------------------------------
def pagina2(request):
    return render(request, 'resultmetricas.html', context={})

def pagina3(request):
    return render(request, 'resulmetricas2.html', context={})


def main(request):
    # *** Plantilla ***
    return render(request, 'index.html', context={})



def prediccion(request):

    ### Se cargan los datos
    data = pd.read_csv("C:/Users/carlo/OneDrive/Escritorio/IA2025Aii/django_ml/proyecto/data/data.csv", sep=";")

    

    ### Se realiza el balanceo de los datos (oversample)
    df_cero = data[ data['target'] == 0 ]
    df_uno = data[ data['target'] == 1 ]

    df_oversample_cero = resample(df_cero,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df_oversample_uno = resample(df_uno,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df = pd.concat( [df_oversample_cero, df_oversample_uno] )


    ### Se definen las características y variable objetivo
    features = ['STslope','chest_pain_type','max_heart_rate','oldpeak']
    # Características
    X = df[features]
    # Variable objetivo
    y = df['target'].values

    # Se separan los datos (80% entrenamiento y 20% pruebas)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state= 1)

    ### Se genera la predicción sin hiperparámetros
    # Se selecciona el algoritmo
    dt = DecisionTreeClassifier()

    # Se entrena el algoritmo
    dt.fit(X_train, y_train)

    # Se genera la predicción
    predict = dt.predict(X_test)

    # Se convierten los valores a listas
    test= y_test.tolist()
    prediction = predict.tolist()


    # Se envian los valores al contexto para renderizar
    context = {"test": test,
               "prediction": prediction,
    
               
                }

    # *** Plantilla ***
    return render(request, 'index.html', context=context)










def prediccion2(request):

    ### Se cargan los datos
    data = pd.read_csv("C:/Users/carlo/OneDrive/Escritorio/IA2025Aii/django_ml/proyecto/data/data.csv", sep=";")

    ### Se modifica luvioso por lluvioso
  

    ### Se cambian las cadenas a valores numéricos
    

    ### Se realiza el balanceo de los datos (oversample)
    df_cero = data[ data['target'] == 0 ]
    df_uno = data[ data['target'] == 1 ]

    df_oversample_cero = resample(df_cero,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df_oversample_uno = resample(df_uno,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df = pd.concat( [df_oversample_cero, df_oversample_uno] )

    ### DT 80-20
    ### Se definen las características y variable objetivo
    features = ['STslope','chest_pain_type','max_heart_rate','oldpeak']
    # Características
    X = df[features]
    # Variable objetivo
    y = df['target'].values

    # Se separan los datos (80% entrenamiento y 20% pruebas)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state= 1)

        ### Se genera la predicción Arbol de decision sin hiperparámetros
    # Se selecciona el algoritmo
    dt = DecisionTreeClassifier()

    # Se entrena el algoritmo
    dt.fit(X_train, y_train)

    # Se genera la predicción
    predict = dt.predict(X_test)

    
     # Se convierten los valores a listas
    test= y_test.tolist()
    prediction = predict.tolist()

    # Se imprimen las métricas

    print(confusion_matrix(y_test, predict))
    print(classification_report(y_test, predict))
    dt_Precision80_20 = round(precision_score(y_test, predict),2)
    print("Precisión:", dt_Precision80_20)
    dt_Recall80_20 = round(recall_score(y_test, predict),2)
    print("Recall:", dt_Recall80_20)
    dt_f180_20 = round(f1_score(y_test, predict),2)
    print("F1-Score:", dt_f180_20)


    ### Se genera la predicción Naive Bayes sin hiperparámetros 80-20

        # Se crea el modelo
    nb = GaussianNB()

    # Se entrena el algoritmo
    nb.fit(X_train, y_train)

    # Se genera la predicción
    predict = nb.predict(X_test)

    # Se imprimen las métricas
    print(confusion_matrix(y_test, predict))
    print(classification_report(y_test, predict))
    nb_precision80_20 = round(precision_score(y_test, predict),2)
    print("Precisión:", nb_precision80_20)
    nb_recall80_20 = round(recall_score(y_test, predict),2)
    print("Recall:",nb_recall80_20)
    nb_f180_20 = round(f1_score(y_test, predict),2)
    print("F1-Score:", nb_f180_20 )


    ### Se genera la predicción SVC sin hiperparámetros 80-20

    # Se selecciona el algoritmo
    svc = SVC()

    # Se entrena el algoritmo
    svc.fit(X_train, y_train)

    # Se genera la predicción
    predict = svc.predict(X_test)

    # Se imprimen las métricas
    print(confusion_matrix(y_test, predict))
    print(classification_report(y_test, predict))

    svc_precision80_20 = round(precision_score(y_test, predict),2)
    print("Precisión:", svc_precision80_20)
    svc_recall80_20 = round(recall_score(y_test, predict),2)
    print("Recall:",svc_recall80_20)
    svc_f180_20 = round(f1_score(y_test, predict),2)
    print("F1-Score:",svc_f180_20)



    ### Se realiza el balanceo de los datos (oversample)
    df_cero = data[ data['target'] == 0 ]
    df_uno = data[ data['target'] == 1 ]

    df_oversample_cero = resample(df_cero,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df_oversample_uno = resample(df_uno,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df = pd.concat( [df_oversample_cero, df_oversample_uno] )

    ### DT 80-20
    ### Se definen las características y variable objetivo
    features = ['STslope','chest_pain_type','max_heart_rate','oldpeak']
    # Características
    X = df[features]
    # Variable objetivo
    y = df['target'].values

    # Se separan los datos (80% entrenamiento y 20% pruebas)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state= 1)

    ### Se genera la predicción Arbol de decision con hiperparámetros 80-20

    
    ### Hiperparámetros con GridSearch
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    dt = DecisionTreeClassifier()

    # Parámetros
    criterion = ['gini', 'entropy', 'log_loss']
    splitter = ['best', 'random']
    min_samples_split = [ 2, 5, 10]


    grid = dict(criterion = criterion,
                splitter = splitter,
                min_samples_split = min_samples_split)

    grid_search = GridSearchCV(estimator = dt,
                            param_grid = grid,
                            cv= 10,
                            verbose=1,
                            n_jobs=-1,
                            scoring = "accuracy")

    searchResults = grid_search.fit(X_train, y_train.ravel())

    # extract the best model and evaluate it
    bestModel = searchResults.best_estimator_

    print("Best Parameters (GridSearch):", bestModel)
    print("-----------------------------------------------------------")

    # Se crea un objeto con los mejores ajustes de Hiperparámetros
    dt = bestModel

    # Se entrena el modelo con los mejores parámetros
    dt.fit(X_train, y_train)

    pred = dt.predict(X_test)

    # Se imprime la matriz de confusión
    print(confusion_matrix(y_test, pred))
    # Se imprime la precisión del modelo
    print(classification_report(y_test, pred))

    # Otras métricas clasificación: Precisión, Recall, F1-Score
    dt_hprecision80_20 = round(precision_score(y_test, pred), 2)
    print("Precisión: ",dt_hprecision80_20)
    dt_hrecall80_20 = round(recall_score(y_test, pred),2)
    print("Recall: ",dt_hrecall80_20)
    dt_hf180_20 = round(f1_score(y_test, pred),2)
    print("F1-Score: ",dt_hf180_20)



    #Se genera la predicción Naive Bayes con hiperparámetro 80-20

        # Se crea el modelo
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    nb = GaussianNB()

    #Parametros

    grid = {
        'var_smoothing': np.logspace(0,-9, num=100)
    }

    grid_search = GridSearchCV(estimator = nb,
                            param_grid = grid,
                            cv= 10,
                            verbose=1,
                            n_jobs=-1,
                            scoring = "accuracy")

    searchResults = grid_search.fit(X_train, y_train.ravel())

    ##extraer el mejor modelo y evaluarlo
    bestModel = searchResults.best_estimator_

    print("Best Parameters (GridSearch):", bestModel)
    print("-----------------------------------------------------------")

    nb = bestModel

    # Se entrena el modelo
    nb.fit(X_train, y_train)

    # Se genera la predicción
    pred = nb.predict(X_test)

    # Matriz de confusión
    print(confusion_matrix(y_test, pred))
    print(classification_report(y_test, pred))

    # Precisión
    nb_hprecision80_20 = round(precision_score(y_test, pred), 2)
    print("Precisión: ", nb_hprecision80_20)
    # Recall
    nb_hrecall80_20 = round(recall_score(y_test, pred),2)
    print("Recall: ",nb_hrecall80_20)
    # F1 score
    nb_hf180_20 = round(f1_score(y_test, pred),2)
    print("F1-Score: ",nb_hf180_20)


    #Se genera la predicción SVC con hiperparámetros 80-20

        # Se crea el modelo
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # Definir rangos de valores para los hiperparámetros gamma y C
    gamma_range = [0.001, 0.01, 0.1, 1, 10]
    C_range = [0.1, 1, 10, 100]

    svc = SVC()

    grid = {'gamma': gamma_range, 'C': C_range}

    # Parámetros
    grid_search = GridSearchCV(estimator=svc, param_grid=grid,
                            cv=10, verbose=1,
                            n_jobs=-1, scoring="accuracy")

    searchResults = grid_search.fit(X_train, y_train.ravel())

    # Extraer el mejor modelo y evaluarlo
    bestModel = searchResults.best_estimator_

    print("Mejores Parametros (GridSearch):", bestModel)
    print("-----------------------------------------------------------")

    svc = bestModel

    # Se entrena el modelo
    svc.fit(X_train, y_train)

    # Se genera la predicción
    pred = svc.predict(X_test)

    # Matriz de confusión
    print(confusion_matrix(y_test, pred))
    # Precisión
    svc_hprecision80_20 = round(precision_score(y_test, pred), 2)
    print("Precisión: ", svc_hprecision80_20)
    # Recall
    svc_hrecall80_20 = round(recall_score(y_test, pred), 2)
    print("Recall: ", svc_hrecall80_20)
    # F1 score
    svc_hf180_20 = round(f1_score(y_test, pred), 2)
    print("F1-Score: ", svc_hf180_20)


    #COMPARAR ALGORITMOS CON SIN PARAMETROS

            # Almacenar métricas para algoritmos sin hiperparámetros
    dt_metrics = {
            "Precision": dt_Precision80_20,
            "Recall": dt_Recall80_20,
            "f1score": dt_f180_20
        }

    nb_metrics = {
            "Precision": nb_precision80_20,
            "Recall": nb_recall80_20,
            "f1score": nb_f180_20
        }

    svc_metrics = {
            "Precision": svc_precision80_20,
            "Recall": svc_recall80_20,
            "f1score": svc_f180_20
        }

        # Calcular métricas para algoritmos con hiperparámetros
        # ...

        # Almacenar métricas para algoritmos con hiperparámetros
    dt_h_metrics = {
            "Precision": dt_hprecision80_20,
            "Recall": dt_hrecall80_20,
            "f1score": dt_hf180_20
        }

    nb_h_metrics = {
            "Precision": nb_hprecision80_20,
            "Recall": nb_hrecall80_20,
            "f1score": nb_hf180_20
        }

    svc_h_metrics = {
            "Precision": svc_hprecision80_20,
            "Recall": svc_hrecall80_20,
            "f1score": svc_hf180_20
        }




    # Se envian los valores al contexto para renderizar
    context = {"test": test,
               "prediction": prediction,
             
                
               "dt_Precision80_20":dt_Precision80_20,
               "dt_Recall80_20":dt_Recall80_20,
               "dt_f180_20":dt_f180_20,


               "nb_precision80_20": nb_precision80_20,
               "nb_recall80_20": nb_recall80_20,
               "nb_f180_20":nb_f180_20,


                "svc_precision80_20": svc_precision80_20,
                "svc_recall80_20": svc_recall80_20,
                "svc_f180_20":svc_f180_20,


                 
               "dt_hprecision80_20":dt_hprecision80_20,
               "dt_hrecall80_20":dt_hrecall80_20,
               "dt_hf180_20":dt_hf180_20,


               "nb_hprecision80_20": nb_hprecision80_20,
               "nb_hrecall80_20": nb_hrecall80_20,
               "nb_hf180_20":nb_hf180_20,


                "svc_hprecision80_20": svc_hprecision80_20,
                "svc_hrecall80_20": svc_hrecall80_20,
                "svc_hf180_20":svc_hf180_20,


                "dt_metrics": dt_metrics,
                "nb_metrics": nb_metrics,
                "svc_metrics": svc_metrics,
                "dt_h_metrics": dt_h_metrics,
                "nb_h_metrics": nb_h_metrics,
                "svc_h_metrics": svc_h_metrics
                
               
                }
    


    # *** Plantilla ***
    return render(request, 'resultmetricas.html', context=context)



### # 70% entrenamiento y 30% pruebas

def prediccion3(request):

    ### Se cargan los datos
    data = pd.read_csv("C:/Users/carlo/OneDrive/Escritorio/IA2025Aii/django_ml/proyecto/data/data.csv", sep=";")

    ### Se modifica luvioso por lluvioso
  

    ### Se cambian las cadenas a valores numéricos
    

    ### Se realiza el balanceo de los datos (oversample)
    df_cero = data[ data['target'] == 0 ]
    df_uno = data[ data['target'] == 1 ]

    df_oversample_cero = resample(df_cero,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df_oversample_uno = resample(df_uno,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df = pd.concat( [df_oversample_cero, df_oversample_uno] )

    ### DT 80-20
    ### Se definen las características y variable objetivo
    features = ['STslope','chest_pain_type','max_heart_rate','oldpeak']
    # Características
    X = df[features]
    # Variable objetivo
    y = df['target'].values

    # Se separan los datos (70% entrenamiento y 30% pruebas)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state= 1)

   
        

    ### Se genera la predicción Arbol de decision sin hiperparámetros
    # Se selecciona el algoritmo
    dt = DecisionTreeClassifier()

    # Se entrena el algoritmo
    dt.fit(X_train, y_train)

    # Se genera la predicción
    predict = dt.predict(X_test)

     # Se convierten los valores a listas
    test= y_test.tolist()
    prediction = predict.tolist()

    # Se imprimen las métricas

    print(confusion_matrix(y_test, predict))
    print(classification_report(y_test, predict))
    dt_Precision70_30 = round(precision_score(y_test, predict),2)
    print("Precisión:", dt_Precision70_30)
    dt_Recall70_30 = round(recall_score(y_test, predict),2)
    print("Recall:", dt_Recall70_30)
    dt_f170_30 = round(f1_score(y_test, predict),2)
    print("F1-Score:", dt_f170_30)


    ### Se genera la segunda predicción y se calculan las métricas NB(70% y 30%)

    # Se crea el modelo
    nb = GaussianNB()

    # Se entrena el algoritmo
    nb.fit(X_train, y_train)

    # Se genera la predicción
    predict = nb.predict(X_test)

    # Se imprimen las métricas
    print(confusion_matrix(y_test, predict))
    print(classification_report(y_test, predict))
    nb_precision70_30 = round(precision_score(y_test, predict),2)
    print("Precisión:", nb_precision70_30)
    nb_recall70_30 = round(recall_score(y_test, predict),2)
    print("Recall:",nb_recall70_30)
    nb_f170_30 = round(f1_score(y_test, predict),2)
    print("F1-Score:", nb_f170_30 )


    ### Se genera la predicción SVC 70-30
    # Se selecciona el algoritmo
    svc = SVC()

    # Se entrena el algoritmo
    svc.fit(X_train, y_train)

    # Se genera la predicción
    predict = svc.predict(X_test)

    # Se imprimen las métricas
    print(confusion_matrix(y_test, predict))
    print(classification_report(y_test, predict))

    svc_precision70_30 = round(precision_score(y_test, predict),2)
    print("Precisión:", svc_precision70_30)
    svc_recall70_30 = round(recall_score(y_test, predict),2)
    print("Recall:",svc_recall70_30)
    svc_f170_30 = round(f1_score(y_test, predict),2)
    print("F1-Score:",svc_f170_30)

    
### ### Se genera la predicción Arbol de decision con hiperparámetros 70-30


 ### Se realiza el balanceo de los datos (oversample)
    df_cero = data[ data['target'] == 0 ]
    df_uno = data[ data['target'] == 1 ]

    df_oversample_cero = resample(df_cero,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df_oversample_uno = resample(df_uno,
                           replace=True,
                           n_samples=629,
                           random_state = 1)

    df = pd.concat( [df_oversample_cero, df_oversample_uno] )

    ### DT 80-20
    ### Se definen las características y variable objetivo
    features = ['STslope','chest_pain_type','max_heart_rate','oldpeak']
    # Características
    X = df[features]
    # Variable objetivo
    y = df['target'].values

    # Se separan los datos (70% entrenamiento y 30% pruebas)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state= 1)

   



        ### Hiperparámetros con GridSearch
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    dt = DecisionTreeClassifier()

    # Parámetros
    criterion = ['gini', 'entropy', 'log_loss']
    splitter = ['best', 'random']
    min_samples_split = [ 2, 5, 10]


    grid = dict(criterion = criterion,
                splitter = splitter,
                min_samples_split = min_samples_split)

    grid_search = GridSearchCV(estimator = dt,
                            param_grid = grid,
                            cv= 10,
                            verbose=1,
                            n_jobs=-1,
                            scoring = "accuracy")

    searchResults = grid_search.fit(X_train, y_train.ravel())

    # extract the best model and evaluate it
    bestModel = searchResults.best_estimator_

    print("Best Parameters (GridSearch):", bestModel)
    print("-----------------------------------------------------------")

    # Se crea un objeto con los mejores ajustes de Hiperparámetros
    dt = bestModel

    # Se entrena el modelo con los mejores parámetros
    dt.fit(X_train, y_train)

    pred = dt.predict(X_test)

    # Se imprime la matriz de confusión
    print(confusion_matrix(y_test, pred))
    # Se imprime la precisión del modelo
    print(classification_report(y_test, pred))

    # Otras métricas clasificación: Precisión, Recall, F1-Score
    dt_hprecision70_30 = round(precision_score(y_test, pred, average='weighted'), 2)
    print("Precisión: ",dt_hprecision70_30)
    dt_hrecall70_30 = round(recall_score(y_test, pred, average='weighted'),2)
    print("Recall: ",dt_hrecall70_30)
    dt_hf170_30 = round(f1_score(y_test, pred, average='weighted'),2)
    print("F1-Score: ",dt_hf170_30)


    ##Se genera la predicción Naive Bayes con hiperparámetros 70-30
# Se crea el modelo
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    nb = GaussianNB()

    # Parametros
    grid = {
        'priors': [None],  # Puedes ajustar los priors si lo deseas
        'var_smoothing': np.logspace(0,-9, num=100)
    }

    grid_search = GridSearchCV(estimator=nb,
                            param_grid=grid,
                            cv=10,
                            verbose=1,
                            n_jobs=-1,
                            scoring="accuracy")

    searchResults = grid_search.fit(X_train, y_train.ravel())

    ## Extraer el mejor modelo y evaluarlo
    bestModel = searchResults.best_estimator_

    print("Best Parameters (GridSearch):", bestModel)
    print("-----------------------------------------------------------")

    nb = bestModel

    # Se entrena el modelo
    nb.fit(X_train, y_train)

    # Se genera la predicción
    pred = nb.predict(X_test)

    # Matriz de confusión
    print(confusion_matrix(y_test, pred))
    print(classification_report(y_test, pred))

    # Precisión
    nb_hprecision70_30 = round(precision_score(y_test, pred), 2)
    print("Precisión: ", nb_hprecision70_30)
    # Recall
    nb_hrecall70_30 = round(recall_score(y_test, pred), 2)
    print("Recall: ", nb_hrecall70_30)
    # F1 score
    nb_hf170_30 = round(f1_score(y_test, pred), 2)
    print("F1-Score: ", nb_hf170_30)

    ##Se genera la predicción SVC con hiperparámetros 70-30

        # Se crea el modelo
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # Definir rangos de valores para los hiperparámetros gamma y C
    gamma_range = [0.001, 0.01, 0.1, 1, 10]
    C_range = [0.1, 1, 10, 100]

    svc = SVC()

    grid = {'gamma': gamma_range, 'C': C_range}

    # Parámetros
    grid_search = GridSearchCV(estimator=svc, param_grid=grid,
                            cv=10, verbose=1,
                            n_jobs=-1, scoring="accuracy")

    searchResults = grid_search.fit(X_train, y_train.ravel())

    # Extraer el mejor modelo y evaluarlo
    bestModel = searchResults.best_estimator_

    print("Mejores Parametros (GridSearch):", bestModel)
    print("-----------------------------------------------------------")

    svc = bestModel

    # Se entrena el modelo
    svc.fit(X_train, y_train)

    # Se genera la predicción
    pred = svc.predict(X_test)

    # Matriz de confusión
    print(confusion_matrix(y_test, pred))
    # Precisión
    svc_hprecision70_30 = round(precision_score(y_test, pred), 2)
    print("Precisión: ", svc_hprecision70_30)
    # Recall
    svc_hrecall70_30 = round(recall_score(y_test, pred), 2)
    print("Recall: ", svc_hrecall70_30)
    # F1 score
    svc_hf170_30 = round(f1_score(y_test, pred), 2)
    print("F1-Score: ", svc_hf170_30)


    

    context = {"test": test,
               "prediction": prediction,

               "dt_f170_30":dt_f170_30,
               "dt_Precision70_30":dt_Precision70_30,
               "dt_Recall70_30":dt_Recall70_30,
               "nb_f170_30":nb_f170_30,
               "nb_precision70_30":nb_precision70_30,
               "nb_recall70_30":nb_recall70_30,
               "svc_f170_30":svc_f170_30,
               "svc_precision70_30":svc_precision70_30,
               "svc_recall70_30":svc_recall70_30,

               "svc_hf170_30":svc_hf170_30,
               "svc_hrecall70_30":svc_hrecall70_30,
               "svc_hprecision70_30":svc_hprecision70_30,
               "nb_hf170_30":nb_hf170_30,
               "nb_hrecall70_30":nb_hrecall70_30,
               "nb_hprecision70_30":nb_hprecision70_30,
               "dt_hf170_30":dt_hf170_30,
               "dt_hrecall70_30":dt_hrecall70_30,
               "dt_hprecision70_30":dt_hprecision70_30,






               }
     
    return render(request, 'resulmetricas2.html', context=context)
