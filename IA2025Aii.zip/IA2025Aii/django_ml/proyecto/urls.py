"""proyecto2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from proyecto.views import main
from proyecto.views import prediccion
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('main/', main, name='main'),   # Directa
    path('', main, name='home'),  # Directa
    path('prediccion/', prediccion),    # Botones
    path('pagina2/', views.pagina2, name='pagina2'),
     path('pagina3/', views.pagina3, name='pagina3'),
    path('prediccion2/', views.prediccion2, name='prediccion2'),
    path('prediccion3/', views.prediccion3, name='prediccion3'),
   
]
